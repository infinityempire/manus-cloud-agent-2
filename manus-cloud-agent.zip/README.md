# Manus Cloud Agent

בוט טלגרם בענן שמריץ Pipelines בגיטלאב, מפרסם Release בגיטהאב, ועונה עם AI.
